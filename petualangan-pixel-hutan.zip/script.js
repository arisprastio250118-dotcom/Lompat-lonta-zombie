const canvas = document.getElementById("game");
const ctx = canvas.getContext("2d");

let player = {x:50, y:220, w:16, h:16, vy:0, speed:150, jump:350, hp:5};
let obstacles = [];
let enemies = [];
let coins = [];
let score = 0;
let gravity = 900;
let gameOver = false;
let keys = {};
let lastTime = 0;

// Input
window.addEventListener("keydown", e => { keys[e.key] = true; });
window.addEventListener("keyup", e => { keys[e.key] = false; });

// Spawn functions
function rand(a,b){return Math.random()*(b-a)+a;}
function spawnObstacle(){obstacles.push({x:canvas.width, y:240, w:16, h:16});}
function spawnCoin(){coins.push({x:canvas.width+rand(50,150), y:rand(150,220), r:6});}
function spawnEnemy(){enemies.push({x:canvas.width, y:220, w:16, h:16, dir:-1});}

// Reset
function reset(){
  player.y=220; player.vy=0; player.hp=5; score=0;
  obstacles=[]; coins=[]; enemies=[]; gameOver=false;
  updateHUD();
}

function updateHUD(){
  document.getElementById("hp").textContent = "Nyawa: "+player.hp;
  document.getElementById("score").textContent = "Skor: "+score;
}

// Game Loop
function update(dt){
  if(gameOver) return;

  // Player movement
  if(keys['ArrowLeft']) player.x -= player.speed*dt;
  if(keys['ArrowRight']) player.x += player.speed*dt;
  if((keys['ArrowUp'] || keys[' ']) && player.y===220) player.vy=-player.jump;

  player.vy += gravity*dt;
  player.y += player.vy*dt;
  if(player.y>220){player.y=220; player.vy=0;}

  // Obstacles
  for(let i=obstacles.length-1;i>=0;i--){
    let o = obstacles[i]; o.x -= 200*dt;
    if(o.x+o.w<0){obstacles.splice(i,1); score++; updateHUD();}
    if(player.x<o.x+o.w && player.x+player.w>o.x && player.y<o.y+o.h && player.y+player.h>o.y){
      player.hp--; updateHUD(); obstacles.splice(i,1);
      if(player.hp<=0) gameOver=true;
    }
  }

  // Coins
  for(let i=coins.length-1;i>=0;i--){
    let c=coins[i]; c.x-=200*dt;
    if(Math.hypot(player.x+player.w/2 - c.x, player.y+player.h/2 - c.y)<12){
      coins.splice(i,1); score+=5; updateHUD();
    }
    else if(c.x<0) coins.splice(i,1);
  }

  // Enemies
  for(let i=enemies.length-1;i>=0;i--){
    let e=enemies[i]; e.x+=e.dir*100*dt;
    if(e.x<0 || e.x>canvas.width) e.dir*=-1;
    if(player.x<e.x+e.w && player.x+player.w>e.x && player.y<e.y+e.h && player.y+player.h>e.y){
      player.hp--; updateHUD();
      if(player.hp<=0) gameOver=true;
    }
  }

  if(Math.random()<0.02) spawnObstacle();
  if(Math.random()<0.01) spawnCoin();
  if(Math.random()<0.005) spawnEnemy();
}

function draw(){
  ctx.fillStyle="#0b1622"; ctx.fillRect(0,0,canvas.width,canvas.height);
  // Player
  ctx.fillStyle="#7bd389"; ctx.fillRect(player.x,player.y,player.w,player.h);
  // Obstacles
  ctx.fillStyle="#b33a3a"; for(let o of obstacles) ctx.fillRect(o.x,o.y,o.w,o.h);
  // Coins
  ctx.fillStyle="#f6d365"; for(let c of coins){ctx.beginPath();ctx.arc(c.x,c.y,c.r,0,2*Math.PI);ctx.fill();}
  // Enemies
  ctx.fillStyle="#ff77aa"; for(let e of enemies) ctx.fillRect(e.x,e.y,e.w,e.h);
  if(gameOver){ctx.fillStyle="rgba(0,0,0,0.6)";ctx.fillRect(0,0,canvas.width,canvas.height);
  ctx.fillStyle="#fff"; ctx.font="18px monospace"; ctx.textAlign="center";
  ctx.fillText("Game Over! Tekan R untuk restart",canvas.width/2,canvas.height/2);}
}

function loop(ts){
  lastTime||(lastTime=ts);
  const dt=Math.min(0.05,(ts-lastTime)/1000);
  lastTime=ts;
  update(dt); draw(); requestAnimationFrame(loop);
}
requestAnimationFrame(loop);

window.addEventListener("keydown", e=>{if(e.key==='r') reset();});
